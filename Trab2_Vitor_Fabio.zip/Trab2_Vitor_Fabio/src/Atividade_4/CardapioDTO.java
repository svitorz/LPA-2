
package Atividade_4;

public class CardapioDTO {
   private int  Codigo,Numero_h,Numero_c,Numero_m,Numero_a,Numero_q;
   private double Valor_total;

    public int getCodigo() {
        return Codigo;
    }

    public void setCodigo(int Codigo) {
        this.Codigo = Codigo;
    }

    public int getNumero_h() {
        return Numero_h;
    }

    public void setNumero_h(int Numero_h) {
        this.Numero_h = Numero_h;
    }

    public int getNumero_c() {
        return Numero_c;
    }

    public void setNumero_c(int Numero_c) {
        this.Numero_c = Numero_c;
    }

    public int getNumero_m() {
        return Numero_m;
    }

    public void setNumero_m(int Numero_m) {
        this.Numero_m = Numero_m;
    }

    public int getNumero_a() {
        return Numero_a;
    }

    public void setNumero_a(int Numero_a) {
        this.Numero_a = Numero_a;
    }

    public int getNumero_q() {
        return Numero_q;
    }

    public void setNumero_q(int Numero_q) {
        this.Numero_q = Numero_q;
    }

    public double getValor_total() {
        return Valor_total;
    }

    public void setValor_total(double Valor_total) {
        this.Valor_total = Valor_total;
    }
}
